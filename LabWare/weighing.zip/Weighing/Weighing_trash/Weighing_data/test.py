import serial
import time
# 시리얼 포트 설정
# ser = serial.Serial('/dev/ttyweighing', 9600, timeout=1)  # Windows 예시
ser = serial.Serial('/dev/ttyweighing', 9600, timeout=1)  # Linux/Mac 예시


# Escape 문자
import serial

# Open serial connection
# ser = serial.Serial('COM1', 9600)  # Replace 'COM1' with the appropriate port and baud rate

# Send command to print weight display value
# Function to send SBI commands and receive responses
def send_sbi_command(command):
    ser.write(command.encode())
    response = ser.readline().decode().strip()
    return response

# Example commands
# send_sbi_command('\x1BT')
# time.sleep(2)
# send_sbi_command('\x1Bw8_')
# time.sleep(2)
# send_sbi_command('\x1Bw2_')
# time.sleep(2)
output_value = send_sbi_command('\x1Bw7_')

print("Output Value:", output_value)
time.sleep(5)

# set_ambient_condition = send_sbi_command('\x1BK')
# print("Set Ambient Condition:", set_ambient_condition)

# Close the serial port connection
ser.close()