# @breif [Hardware] Pioneer Weight Machine 
# @author HeeSeung Lee (092508@kist.re.kr)
# @version 1.0 
# Test 2023 - 01 - 08



import serial
import time
import sys, os 

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../")))
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../../")))
from Log.Logging_Class import NodeLogger
class Pioneer():

    """
    [weighing Machine model] Ohaus Pioneer PX224KR/E
    :param device_nmae = "pioneer" (string) : set Weighing Machine model name
    :param PORT = "COM8" (str) : Write your connected Weighing Machine Port 
    "param BAUD_RATE = 9600 (int)
    "param mode_type = "virutal (str): set virtual or real mode 
    "command code:  
    "IP\r\n" : Immediate Print of displayed weight
    "P\r\n" : Print displayed weight (uses Stable ON/OFF menu settings)
    "Z\r\n" : Same as pressing Zero Key
    "ON\r\n" : Turns balance ON.
    "OFF\r\n" : Turns balance OFF.
    """ 
    def __init__(self,  logger_obj,device_name="pioneer"):
        self.logger_obj = logger_obj
        self.Pioneer_info = {
            "PORT" : "/dev/ttyUSB0",
            "BAUD_RATE" : 9600
        }
        # self.logger = logger
        self.device_name = device_name
        self.scale = serial.Serial(self.Pioneer_info["PORT"],self.Pioneer_info["BAUD_RATE"],bytesize=7,stopbits=1)

    def hello(self,):
            res_msg = "say HI"
            command = "P\r\n"

            self.scale.write(command.encode('utf-8'))
            weight = self.scale.readline()
            
            return_res_msg = "{}".format(weight.decode('utf-8').strip())
            result = return_res_msg.replace(" ", "")
            print("initialize",result)
            self.logger_obj.debug(self.device_name, res_msg)

            return res_msg

    def setInitialize(self,mode_type = "virtual"):

        """
        :param action_type="" (str): set action type (추후 추가 예정)
        :param mode_type="virtual" (str): set virtual or real mode
        :param command :("Z\r\n")  set initialize 
    
        
        """

        if mode_type =="real":

            debug_msg =   "Initialize"
            self.logger_obj.debug(device_name=self.device_name, debug_msg=debug_msg)

            command = "w5_\r"

            self.scale.write(command.encode('utf-8'))
            weight = self.scale.readline()
            
            return_res_msg = "{}".format(weight.decode('utf-8').strip())

            result = return_res_msg.replace(" ", "")
            # print("initialize",result)
            

            return result

        elif mode_type =="virtual":

            debug_msg =   "Initialize {}".format(mode_type)
            self.logger_obj.debug(device_name=self.device_name, debug_msg=debug_msg)
            return print(debug_msg)

    def getWeightValue(self,mode_type="virtual"):
        """
        objectName = Powder, IPA, Nafion, Water
        """
        debug_msg =   "Measure Sample"
        self.logger_obj.debug(device_name=self.device_name, debug_msg=debug_msg)
        if mode_type =="real": 
            debug_msg = "Get Weight Value"

            command ="\nw1\r\n"

            self.scale.write(command.encode('utf-8'))
            weight = self.scale.readline()
            
            return_res_msg = "{}".format(weight.decode('utf-8').strip())
            result = return_res_msg.replace(" ", "")
            # print(result)

            real_value = result.strip("g,?")

            print(real_value)
            # return float(real_value)

        elif mode_type =="virtual":
            debug_msg =   "Pioneer Weighing Machine Virtual Mode "
            self.logger_obj.debug(device_name=self.device_name, debug_msg=debug_msg)
            return print(return_res_msg)

            

if __name__ == '__main__':
    import time
    from Log.Logging_Class import NodeLogger
    NodeLogger_obj=NodeLogger(platform_name="Robot Platform", setLevel="DEBUG", SAVE_DIR_PATH="C:/Users/KIST/PycharmProjects/BatchPlatform")
    pioneer_obj = Pioneer(NodeLogger_obj,device_name="pioneer")
    # for i in range(10):
    pioneer_obj.setInitialize(mode_type="real")
    #     pioneer_obj.setInitialize(mode_type="real")
    #     time.sleep(3)
    
    # time.sleep(3)