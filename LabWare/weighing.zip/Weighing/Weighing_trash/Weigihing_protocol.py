from weighing import * 
import os
import time
import pandas as pd 


import datetime

df = pd.DataFrame(columns=['idx', 'Weight'])

pioneer_obj = Pioneer(device_name="pioneer")


for idx in range(1, 10): 
    pioneer_obj.setInitialize(mode_type="real")

    time.sleep(5)
    df = df.append(pd.DataFrame([[idx,pioneer_obj.getWeightValue(mode_type="real")]],columns=['idx', 'Weight']))
    time.sleep(3)

df.set_index('idx', inplace=True)

print(df)
filename = datetime.datetime.now().strftime("%Y-%m-%d")

df.to_csv(filename+"weight_machine.csv", mode='w')