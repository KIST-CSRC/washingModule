# @breif [Hardware] Pioneer Weight Machine 
# @author HeeSeung Lee (092508@kist.re.kr)
# @version 1.0 
# Test 2023 - 01 - 08



import serial
import time


class Pioneer():

    """
    [weighing Machine model] Ohaus Pioneer PX224KR/E
    :param device_nmae = "pioneer" (string) : set Weighing Machine model name
    :param PORT = "COM8" (str) : Write your connected Weighing Machine Port 
    "param BAUD_RATE = 9600 (int)
    "param mode_type = "virutal (str): set virtual or real mode 
    "command code:  
    "IP\r\n" : Immediate Print of displayed weight
    "P\r\n" : Print displayed weight (uses Stable ON/OFF menu settings)
    "Z\r\n" : Same as pressing Zero Key
    "ON\r\n" : Turns balance ON.
    "OFF\r\n" : Turns balance OFF.
    """ 
    def __init__(self,  device_name="pioneer"):
        self.Pioneer_info = {
            "PORT" : "COM4",
            "BAUD_RATE" : 9600

        }

        # self.logger = logger
        self.device_name = device_name

        self.scale = serial.Serial(self.Pioneer_info["PORT"],self.Pioneer_info["BAUD_RATE"])

    def hello(self,):
            self.scale.write("Z".encode())
            debug_msg="Hello. This is Weighing Machine"
            # self.logger.debug(device_name=self.device_name, debug_msg=debug_msg)

            return_res_msg="[{}] : {}".format(self.device_name, debug_msg)
            return return_res_msg

    def setInitialize(self, mode_type = "virtual"):

        """
        :param action_type="" (str): set action type (추후 추가 예정)
        :param mode_type="virtual" (str): set virtual or real mode
        :param command :("Z\r\n")  set initialize 
    
        
        """
        device_name = "Pioneer Weighing Machine {}".format(mode_type)
         
        if mode_type =="real":

            debug_msg =   "Pioneer Weighing Machine Initialize"
            # self.logger.debug(device_name=self.device_name, debug_msg=debug_msg)

            command = "Z\r\n"

            self.scale.write(command.encode('utf-8'))
            weight = self.scale.readline()
            
            return_res_msg = "{}".format(weight.decode('utf-8').strip())
            result = return_res_msg.replace(" ", "")
            print(result)
            

            return result

        elif mode_type =="virtual":

            debug_msg =   "Pioneer Weighing Machine Initialize {}".format(mode_type)

            return print(debug_msg)

    def getWeightValue(self, mode_type ="virtual"):

        device_name = "Pioneer Weighing Machine {}".format(mode_type)

        if mode_type =="real": 
            debug_msg = "Get Weight Value"

            command ="IP\r\n"

            self.scale.write(command.encode('utf-8'))
            weight = self.scale.readline()
            
            return_res_msg = "{}".format(weight.decode('utf-8').strip())
            result = return_res_msg.replace(" ", "")
            print(result)
            if type(result) == "OK! ":
                self.scale.write(command.encode('utf-8'))
                weight = self.scale.readline()
                return_res_msg = "{}".format(weight.decode('utf-8').strip())
                result = return_res_msg.replace(" ", "")
                real_value = result.strip("g,?")
                return float(real_value)

            

        elif mode_type =="virtual":
            
            debug_msg = "Get Weight Value"

            return_res_msg = "0000g"

        # return print(return_res_msg)

if __name__ == '__main__':
    import time
    pioneer_obj = Pioneer(device_name="pioneer")
    for i in range(10):
        pioneer_obj.setInitialize(mode_type="real")
        time.sleep(3)
        pioneer_obj.getWeightValue(mode_type="real")
        time.sleep(3)